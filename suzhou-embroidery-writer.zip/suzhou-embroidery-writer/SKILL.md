---
name: suzhou-embroidery-writer
description: 苏绣文化内容创作。当用户需要生成苏绣/刺绣主题的演讲稿、研学活动方案、PPT 文字稿、课程教学设计，或需要科普苏绣历史渊源、制作工序、纹样寓意、代表性作品，并要求输出排版整齐的 Markdown 或 Word 文本时使用。触发词：苏绣、刺绣、双面绣、绣娘、劈丝、演讲稿、研学方案、研学活动、PPT 文字稿、教学设计、非遗科普。
agent_created: true
---

# 苏绣文化内容创作

面向苏绣文化推广场景的一站式写作：判定任务 → 取材（知识库）→ 定式（模板）→ 按统一规范排版 → 交付 Markdown，按需转 Word。

## 工作流程

1. 判定任务类型，按表路由：

| 用户要什么 | 处理路径 |
| --- | --- |
| 演讲稿 / 研学活动方案 / PPT 文字稿 / 课程教学设计 | 读 [references/templates.md](references/templates.md) 对应模板，用知识库填充成文 |
| 科普文章（历史渊源 / 制作工序 / 纹样寓意 / 代表性作品） | 依据 [references/knowledge.md](references/knowledge.md) 直接成文 |
| 文档与科普结合（如"带知识的演讲稿"） | 先从知识库列知识提纲，再套模板写作 |
| 需要 Word / docx 成品 | 先成 Markdown 定稿，再按 office_skill_routing 调用 tencent-docs-routing → tencent-docx 生成正式 .docx 并交付文件 |

2. 写作前必读 references/knowledge.md（唯一事实来源），再对照 references/templates.md 选定骨架。
3. 按下方排版规范成文并交付。

## 事实红线

- 所有年代、人物、作品、奖项、数据只允许来自 references/knowledge.md；
- 知识库未覆盖的细节用"相传 / 约 / 据载"等审慎表述，禁止编造数字、年份、获奖记录、师承谱系；
- 场馆开放时间、票价等运营信息一律标注"以实际预约为准"，不得虚构。

## 排版规范（硬性要求）

1. 文档题名用一级标题，章节用二级标题，层级不跳级；
2. 列表统一用 `-` 符号；行程、纹样、作品等多列信息一律用 Markdown 表格；
3. 每个自然段不超过 5 行；专业术语首次出现加粗并简释；
4. 文末固定加 `---` 分隔线与 **知识来源** 小节，注明依据 references/knowledge.md；
5. 中英文之间留空格；禁用表情符号（用户明确要求除外）；
6. 演讲稿文末标注"全文约 X 字，预计 X 分钟"（按每分钟约 250 字估算）。

## 交付

- 默认直接输出 Markdown 文本，或存为 .md 文件交付；
- 用户明确要 Word 时：Markdown 定稿后转交 tencent-docx 技能排版生成 .docx 并交付；
- 交付时附一句后续可生成项（其余三类文档或科普文章），便于用户连续取件。
